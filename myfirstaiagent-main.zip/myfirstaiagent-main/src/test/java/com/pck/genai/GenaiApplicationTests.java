package com.pck.genai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenaiApplicationTests {
	@Test
	void contextLoads() {
	}
}
