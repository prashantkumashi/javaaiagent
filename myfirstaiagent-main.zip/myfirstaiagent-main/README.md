# myfirstaiagent
My first java based AI Agent
